package com.example.dnevnikvjezbanja

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.rule.ActivityTestRule
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AddExerciseUITest {

    // Priprema pravila za pokretanje glavne aktivnosti
    @get:Rule
    val activityRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun testAddExercise() {
        // Klik na navigacijski meni za dodavanje vježbe
        onView(withId(R.id.nav_add)).perform(click())

        // Unesi naziv vježbe
        onView(withId(R.id.editTextExerciseName))
            .perform(typeText("Sklekovi"), closeSoftKeyboard())

        // Unesi trajanje vježbe
        onView(withId(R.id.editTextDuration))
            .perform(typeText("15"), closeSoftKeyboard())

        // Unesi težinu
        onView(withId(R.id.editTextWeight))
            .perform(typeText("70"), closeSoftKeyboard())

        // Klikni na gumb za spremanje vježbe
        onView(withId(R.id.buttonSaveExercise)).perform(click())

        // Navigiraj na početni zaslon s pregledom vježbi
        onView(withId(R.id.nav_home)).perform(click())

        // Provjeri da li se vježba "Sklekovi" pojavljuje u RecyclerView-u
        onView(withText("Sklekovi")).check(matches(isDisplayed()))
    }
}
